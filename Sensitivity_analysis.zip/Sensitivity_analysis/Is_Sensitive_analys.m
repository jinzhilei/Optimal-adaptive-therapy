%% �����Է���
function Is_Sensitive_analys()
%clc;
patientIndex = 1;
cycle = 153;

I0 = load('Optimal_para/y0.dat');  
y0 = initialze(I0(patientIndex,2), I0(patientIndex,3), I0(patientIndex,4));
% ���Ÿ�ҩ�µĲ���������
u = load(strcat('Treatmentdata/',num2str(patientIndex),'A.dat'));
yB = U(u(88:cycle));

M = 10000;

alpha = LHS(1,300,M);
a_mut = LHS(1e-7,1e-2,M);
q_1 = LHS(0.01,0.06,M);
q_3 = LHS(1,20,M);
r_2 = LHS(0.01,0.05,M);
d_2 = LHS(0.0001,0.02,M);

S = zeros(M,6);

% ѭ������
parfor i = 1:M
disp(i)  
Tumor = zeros(1,6);
para = [alpha(i),a_mut(i),q_1(i),q_3(i),r_2(i),d_2(i)];

A = SolveODE_Sensitivity(cycle-87, y0, yB, para);
T0 = A(end,2)+A(end,3);

for j = 1:6   
newpara = para;
newpara(j) = para(j)*1.01;     % �²������ϲ���1% 
newA = SolveODE_Sensitivity(cycle-87, y0, yB, newpara);
Tumor(j) = newA(end,2) + newA(end,3);
S(i,j) = ( (Tumor(j)-T0)/T0 )/( para(j)*0.01/para(j) );
end

end
dlmwrite(strcat('output/Sensitive-optimaldrug3.1','.dat'),S,' ');
plotme(M)
end