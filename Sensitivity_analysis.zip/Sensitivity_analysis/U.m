%
%% using clinical patient data, Complete missing patient data 
function yB = U(u)

global md
control();
h = md.h;

tm = length(u);
t = 0:h:tm;
yB = zeros(size(t,2),1);
for j = 1:1:tm
    yB((j-1)*100+1:j*100 ) = cal(u(j));
end

end


%% Simulate the drug decay process
function y = cal(u)

close all;
global md
control();
h = md.h;

for i = 1:1:1  % (i-1)/0.01+1:i/h+1
    f = @(t,y)-(log(2)/0.3742)*y; % dy/dt = -a*y; 'a' represents the rate of drug decay
    [t((i-1)/h+1:i/h+1),y((i-1)/h+1:i/h+1)] = ode45(f,i-1:h:i,u(i));
end
    n = length(y); 
for j = 1:n
   if y(j) <= 0
       y(j) = 0;
   else 
       y(j) = y(j);
   end
end
y = y(1:100);
end
