%
% This function define the control valuables.
function control()

global md
md.h= 0.01;
md.patientNames = {'P1001','P1002','P1003', 'P1005','P1007', 'P1010', 'P1011', 'P1012', 'P1014', 'P1015', 'P1016', 'P1017', 'P1018', ' C001', ' C002', ' C003', ' C004', ' C005', ' C006', ' C007', ' C008', ' C009', ' C010', ' C011', ' C012', ' C013', ' C014', ' C015'};

end    