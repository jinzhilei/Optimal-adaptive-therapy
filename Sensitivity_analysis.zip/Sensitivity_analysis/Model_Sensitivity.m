
%  [ys,yr,yP,  yPS,yA,yR,  yD,yTS,yB]
function z = Model_Sensitivity(Y,yB,para)

global par
ys = Y(1);
yr = Y(2);
yP = Y(3);
yPS = Y(4);
yA = Y(5);
yR = Y(6);
yD = Y(7);
yTS = Y(8);

z=zeros(1,8);

z(1) = r_1(yA,para).* ( 1 - (par.a_11.*ys+par.a_12.*yr)./par.K )*ys - d_1(yA, para) * ys - para(2).* yB./(1 + yB) .* ys;
z(2) = para(5)*(1 - (par.a_21.*ys + par.a_22.*yr)./par.K).*yr - para(6) * yr + para(2).* yB./(1 + yB) .* ys;

z(3) = par.alpha_1.*yA.*ys + par.alpha_2.*yr + par.c_p - par.gamma_0*yP - para(5).*yP.*(ys + yr).^par.m./(par.K_P + ys + yr) - par.mu_P.*yP;
z(4) = par.gamma_0*yP + par.gamma_P.*yP.*(ys + yr).^par.m./(par.K_P + ys + yr) - par.mu_PS.*yPS;

z(5) = par.k_11.*yR.*yD - par.k_12.*yA - par.mu_A.*yA;   % A
z(6) = par.lambda_R - par.k_11.*yR.*yD + par.k_12.*yA-par.mu_R.*yR;   % R

z(7) = par.beta_D.*yTS/(par.b_D + yTS) + par.beta_0 * exp(-para(1) * yB) .* ys - par.k_11.*yR.*yD + par.k_12.*yA - par.mu_D.*yD;   % D
z(8) = par.lambda_TS - par.beta_D.*yTS/(par.b_D + yTS) - par.mu_TS * yTS;
 
end


% The growth rate of sensitive cells
function r_1 = r_1(yA,para)

global par
r_1 = para(3).*yA.^par.n./(par.q_2.^par.n + yA.^par.n) ;

end

% The death rate of sensitive cells
function d_1 = d_1(yA,para)

global par
d_1 = para(4)/(par.q_4 + yA);

end

