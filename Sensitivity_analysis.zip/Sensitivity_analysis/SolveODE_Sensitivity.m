%
% Solve the model, output the result
% A = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB]
%
function A = SolveODE_Sensitivity(T, y0, yB, para)

global par md
parameter()
control();
h = md.h;
K = par.K;

%% 
nstep = length(0:h:T);
A = zeros(nstep, 10);
% A = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB]
A(1,1) = 0;
A(:,10) = yB;
for i=1:8
    A(1,i+1) = y0(i);
end

for i = 2:nstep
    t = A(i-1,1);
    Y0 = A(i-1,2:9);
    k1 = Model_Sensitivity(Y0, yB(i), para );
    k2 = Model_Sensitivity(Y0 + (h/2)*k1, yB(i), para );
    k3 = Model_Sensitivity(Y0 + (h/2)*k2, yB(i), para );
    k4 = Model_Sensitivity(Y0 + h*k3, yB(i), para );
    
    Y1 = Y0 + (h/6)*(k1 + 2 * k2 + 2 * k3 + k4);
        
    Y1(1) = max(Y1(1) , 0);
    Y1(2) = max(Y1(2) , 0);
    
    Y1(1) = min(Y1(1) , K);
    Y1(2) = min(Y1(2) , K);
    
    Y1(3) = max(Y1(3),0);
    Y1(4) = max(Y1(4),0);   
       
    Y1(5)= max(Y1(5),0);
    Y1(6)= max(Y1(6),0);
    Y1(7)= max(Y1(7),0);
    Y1(8)= max(Y1(8),0);
    
    A(i,1) = t + h;
    A(i,2:9) = Y1;  

end


end


