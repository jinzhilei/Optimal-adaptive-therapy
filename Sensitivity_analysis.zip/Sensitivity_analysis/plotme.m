function plotme(M)


%%
%%     2       5        4       1        3      6
c1 = [10.4/100,0.05/100,3.5/100,76.25/100,9.8/100,0/100];
%%     1       6        3       4       2       5
c2 = [39.9/100,0.45/100,19.4/100,15.95/100,23.5/100,0.8/100];
%%     1       5        2       6       3       4
c3 = [30.9/100,8.1/100,23.95/100,7.3/100,15.4/100,14.35/100];
%%     4       3        5       6       2       1
c4 = [12.55/100,17.05/100,10.2/100,0.4/100,23.7/100,36.1/100];
%%     5       1        4       6       3       2
c5 = [5.5/100,29.4/100,14.95/100,0.05/100,24.8/100,25.3/100];
%%     5       1        2       6       4       3
c6 = [0.75/100,44.95/100,28/100,0.05/100,2.8/100,23.45/100];
subplot(2,3,1)
pie(c1)
subplot(2,3,2)
pie(c2)
subplot(2,3,3)
pie(c3)
subplot(2,3,4)
pie(c4)
subplot(2,3,5)
pie(c5)
subplot(2,3,6)
pie(c6)

%%  %%%%
M = 2000;

rng('default')  % For reproducibility   %  --1000,1---10000,2----total cycle, 3---uped para and half cycle

S = load(strcat('output/Sensitive-optimaldrug','.dat'));

% [A,B] = sort(abs(S),2);
% A
% B
% mode(B)
% tabulate(B(:,1))



figure(1)

subplot(1,2,1)
h = boxplot(S,'Notch','off','Labels',{'��','a_{mut}','q_1','q_3','r_2','d_2'});
% �߿�
set(h,'LineWidth',1.5)
hTitle = title('(A)');
hXLabel = xlabel('Parameter');
hYLabel = ylabel('Sentivity of the number of Cancer cells to parameter');
% ����������
set(gca, 'Box', 'off', ...                                         % �߿�
         'LineWidth', 1,...                                       % �߿�
         'XGrid', 'off', 'YGrid', 'off', ...                      % ����
         'TickDir', 'in', 'TickLength', [.015 .015], ...          % �̶�
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % С�̶�
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1])             % ��������ɫ
% ������ֺ�
set(gca, 'FontName', 'Helvetica')
set([hXLabel, hYLabel], 'FontName', 'AvantGarde','FontWeight','bold')
set(gca, 'FontSize', 12)
set([hXLabel, hYLabel], 'FontSize', 11,'FontWeight' , 'bold')
 set(hTitle, 'FontSize', 11)
 %, 'FontWeight' , 'bold'
% ������ɫ
set(gcf,'Color',[1 1 1])



subplot(1,2,2)

hold on
hYLabel = ylabel('Percentage of parameter');
hXLabel = xlabel('Parameter');
hTitle = title('(B)');
set(hTitle, 'FontSize', 11)
set([hXLabel, hYLabel], 'FontName', 'AvantGarde','FontWeight','bold')
hold on
% subplot(243)
% c = categorical({'��','a_{mut}','q_1','q_3','r_2','d_2'},'Ordinal',true);
% c = reordercats(c,{'��','a_{mut}','q_1','q_3','r_2','d_2'});
% bar(c,[10.4/100,0.05/100,3.5/100,76.25/100,9.8/100,0/100]);
% title('The first sensitive parameter','FontSize',10)
% 
% subplot(244)
% c = categorical({'��','a_{mut}','q_1','q_3','r_2','d_2'},'Ordinal',true);
% c = reordercats(c,{'��','a_{mut}','q_1','q_3','r_2','d_2'});
% bar(c,[39.9/100,0.45/100,19.4/100,15.95/100,23.5/100,0.8/100]);
% title('The second sensitive parameter','FontSize',10)
% 
% subplot(247)
% c = categorical({'��','a_{mut}','q_1','q_3','r_2','d_2'},'Ordinal',true);
% c = reordercats(c,{'��','a_{mut}','q_1','q_3','r_2','d_2'});
% bar(c,[30.9/100,8.1/100,23.95/100,7.3/100,15.4/100,14.35/100]);
% title('The third sensitive parameter','FontSize',10)
% 
% subplot(248)
% c = categorical({'��','a_{mut}','q_1','q_3','r_2','d_2'},'Ordinal',true);
% c = reordercats(c,{'��','a_{mut}','q_1','q_3','r_2','d_2'});
% bar(c,[12.55/100,17.05/100,10.2/100,0.4/100,23.7/100,36.1/100]);
% title('The fourth sensitive parameter','FontSize',10)

%%     2       5        4       1        3      6
c1 = [10.4/100,0.05/100,3.5/100,76.25/100,9.8/100,0/100];
%%     1       6        3       4       2       5
c2 = [39.9/100,0.45/100,19.4/100,15.95/100,23.5/100,0.8/100];
%%     1       5        2       6       3       4
c3 = [30.9/100,8.1/100,23.95/100,7.3/100,15.4/100,14.35/100];
%%     4       3        5       6       2       1
c4 = [12.55/100,17.05/100,10.2/100,0.4/100,23.7/100,36.1/100];
%%     5       1        4       6       3       2
c5 = [5.5/100,29.4/100,14.95/100,0.05/100,24.8/100,25.3/100];
%%     5       1        2       6       4       3
c6 = [0.75/100,44.95/100,28/100,0.05/100,2.8/100,23.45/100];
c1 = sort(c1,'descend');
c2 = sort(c2,'descend');
c3 = sort(c3,'descend');
c4 = sort(c4,'descend');
c5 = sort(c5,'descend');
c6 = sort(c6,'descend');

c = [c1;c2;c3;c4;c5;c6];
bar(c,'stacked');
hold on
 % {'��',  'a_{mut}','q_1',         'q_3',   'r_2',      'd_2'}
 %   2       5        4               1        3           6
 %  ��b     ��y       ��             ��r      ��g         ǳ��
 % 0,0,1   1,1,0     1,0.64606,0    1,0,0    0,1,0     0,0.74902,1
 %   1       6        3               4        2           5
 %   1       5        2               6        3           4
 %   4       3        5               6        2           1
 %   5       1        4               6        3           2
 %   5       1        2               6        4           3
 al = [0,0,1];
 a =  [1,0.64606,0];
 q1 = [0.62745,0.12549,0.94118];
 q3 = [1,0,0];
 r2 = [0,0.74902,1];
 d2 = [0,1,0];
 
 color_matrix = [q3;al;r2;q1;a;d2;
                 al;r2;q1;q3;d2;a;
                 al;q1;r2;d2;a;q3;
                 d2;r2;a;al;q1;q3;
                 a;d2;r2;q1;al;q3;
                 a;q1;d2;r2;al;q3;]; 
% color_matrix = [1,0,0;0,0,1;0,1,0;1,0.64606,0;1,1,0;0,0.74902,1;
%                 0,0,1;0,1,0;1,0.64606,0;1,0,0;0,0.74902,1;1,1,0;
%                 0,0,1;1,0.64606,0;0,1,0;0,0.74902,1;1,1,0;1,0,0
%                 0,0.74902,1;0,1,0;1,1,0;0,0,1;1,0.64606,0;1,0,0;
%                 ];              %4�����ϲ���ɫ
% color_matrix  = [1,0,0;0,0,1;0,1,0;1,0,0;0,0,1;0,1,0];
% c = [1 2 3;4 5 6];
%һ�����������ӣ���b��¼����ʱ����b(i)��facecolor�Ϳ��������޸���ɫ               
c0 = zeros(5,6);
size(c)
for i = 1:6
    b = bar(i:i+1,[c(i,:);0,0,0,0,0,0],0.75,'stacked');  %0.75������ͼ�Ŀ������Ը���
    set(b(1),'facecolor',color_matrix((i-1)*6+1,:))
    set(b(2),'facecolor',color_matrix((i-1)*6+2,:))
    set(b(3),'facecolor',color_matrix((i-1)*6+3,:))
    set(b(3),'facecolor',color_matrix((i-1)*6+3,:))
    set(b(4),'facecolor',color_matrix((i-1)*6+4,:))
    set(b(5),'facecolor',color_matrix((i-1)*6+5,:))
    set(b(6),'facecolor',color_matrix((i-1)*6+6,:))
end

hYLabel = ylabel('Percentage of parameter');
hXLabel = xlabel('Parameter');
set([hXLabel, hYLabel], 'FontName', 'AvantGarde','FontWeight','bold','FontSize',11)



end