
% A = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB]
% B = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB,u]
function Plot1()
% close all
figure(2)
%hold on

id = 17;
%hold on
PatientData = load(strcat('data/patient-',num2str(id),'.dat')); % origial data
u = U(PatientData);
D=load(strcat('data/patient-',num2str(id),'.dat')); % origial data
A=load(strcat('output/A/mdA-',num2str(id),'.dat')); % culculated results

xlin = D(end,1)*1.6;
% xlin=850
K = A(:,5);

%%
global md 
parameter(id)
control()
h = md.h;
ylin = max(max(D(:,2)),max(A(:,5)));
%set(gcf,'outerposition',get(0,'screensize'));
%suptitle({char(patientNames(id))});

subplot(221)
for i = 1:size(D, 1)-1
hold on
%% Plot clinical PSA data
if D(i, 3) == 1
    plot([D(i,1),D(i+1,1)] ,[D(i,2), D(i+1,2)], 'r', 'LineWidth',2, 'MarkerSize',25,'Marker','.');
else
    plot([D(i,1),D(i+1,1)] ,[D(i,2), D(i+1,2)],'Color',[0.549 0.549 0.549], 'LineWidth',2, 'MarkerSize',25,'Marker','.');
end
hold on
end

hold on;
% C6: K(1:317) = linspace(9,10.06,317);  C7: K(1:330) = linspace(0.45,0.4754,330);
plot(A(:,1),K,'k','LineWidth',2);  %
hold on
clinicalPSA = plot([-3,-3],[-3,-3], 'r', 'MarkerSize',25,'Marker','.','LineWidth',2);
modeledPSA = plot([-3,-3],[-3,-3], 'k','LineWidth',3);

legend([clinicalPSA, modeledPSA],'Clinic PSA', 'Modeled PSA');

% --------------------------------------
% ����в�
t = floor(D(:,1));
tdata_num = length(t);
yrealdata = D(:,2);
ypinjun = sum(yrealdata)/tdata_num;

dataTimePoint = zeros(tdata_num,1);
ydata = zeros(tdata_num,1);
cancha = zeros(tdata_num,1);
totalcha = zeros(tdata_num,1);

for i = 1:tdata_num

dataTimePoint(i) = 1 + t(i) /h;         % ѡ��ģ����������ݵ��ʱ���λ��
ydata(i) = A(floor(dataTimePoint(i)),5);   % ģ�������PSA����
cancha(i) = ( yrealdata(i) - ydata(i) )^2; 
totalcha(i) = ( yrealdata(i) - ypinjun )^2;

end

SSE = sum(cancha);
SST = sum(totalcha);
R2 = 1 - SSE/SST;
txt = ['R^2 = ' num2str(R2)];
text(xlin*0.8,2*ylin/3,txt,'FontSize',10)

set(gca, 'FontSize', 12)
ylim([0  ylin*1.2])
xlim([0 xlin]) %
xlabel('Days', 'FontSize', 12)
ylabel('PSA (nM)', 'FontSize', 12)
% ylabel({'Patient PSA and'; 'Optimized Model Fit PSA'}, 'FontSize',12)
title('Patient C004')
box on


%% %%%%%%%%%%%%%%%%
subplot(222)
id = 19;
hold on
PatientData2 = load(strcat('data/patient-',num2str(id),'.dat')); % origial data
% u2 = U(PatientData2);
D2=load(strcat('data/patient-',num2str(id),'.dat')); % origial data
A2=load(strcat('output/A/mdA-',num2str(id),'.dat')); % culculated results

xlin = D2(end,1)*1.6;
% xlin=850
K = A2(:,5);

%%
%global md 
% parameter(id)
% control()
% h = md.h;
%patientNames = md.patientNames;
ylin = max(max(D2(:,2)),max(A2(:,5)));
% set(gcf,'outerposition',get(0,'screensize'));
% suptitle({char(patientNames(id))});

hold on
for i = 1:size(D2, 1)-1
hold on
%% Plot clinical PSA data
if D2(i, 3) == 1
    plot([D2(i,1),D2(i+1,1)] ,[D2(i,2), D2(i+1,2)], 'r', 'LineWidth',2, 'MarkerSize',25,'Marker','.');
else
    plot([D2(i,1),D2(i+1,1)] ,[D2(i,2), D2(i+1,2)],'Color',[0.549 0.549 0.549], 'LineWidth',2, 'MarkerSize',25,'Marker','.');
end
hold on
end

hold on;
 %C6: 
 K(1:317) = linspace(9,10.06,317);  
% C7: K(1:330) = linspace(0.45,0.4754,330);
plot(A2(:,1),K,'k','LineWidth',2);  %
hold on
clinicalPSA = plot([-3,-3],[-3,-3], 'r', 'MarkerSize',25,'Marker','.','LineWidth',2);
modeledPSA = plot([-3,-3],[-3,-3], 'k','LineWidth',3);

legend([clinicalPSA, modeledPSA],'Clinic PSA', 'Modeled PSA');

% --------------------------------------
% ����в�
t = floor(D2(:,1));
tdata_num = length(t);
yrealdata = D2(:,2);
ypinjun = sum(yrealdata)/tdata_num;

dataTimePoint = zeros(tdata_num,1);
ydata = zeros(tdata_num,1);
cancha = zeros(tdata_num,1);
totalcha = zeros(tdata_num,1);

for i = 1:tdata_num

dataTimePoint(i) = 1 + t(i) /h;         % ѡ��ģ����������ݵ��ʱ���λ��
ydata(i) = A2(floor(dataTimePoint(i)),5);   % ģ�������PSA����
cancha(i) = ( yrealdata(i) - ydata(i) )^2; 
totalcha(i) = ( yrealdata(i) - ypinjun )^2;

end

SSE = sum(cancha);
SST = sum(totalcha);
R2 = 1 - SSE/SST;
txt = ['R^2 = ' num2str(R2)];
text(xlin*0.8,2*ylin/3,txt,'FontSize',10)

set(gca, 'FontSize', 12)
ylim([0  ylin*1.2])
xlim([0 xlin]) %
xlabel('Days', 'FontSize', 12)
ylabel('PSA (nM)', 'FontSize', 12)
% ylabel({'Patient PSA and'; 'Optimized Model Fit PSA'}, 'FontSize',12)
title('Patient C006')
hold on
box on

%% %%%%%%%%%%%%%%%%

for id = 20

PatientData3 = load(strcat('data/patient-',num2str(id),'.dat')); % origial data
% u = U(PatientData);
D3=load(strcat('data/patient-',num2str(id),'.dat')); % origial data
A3=load(strcat('output/A/mdA-',num2str(id),'.dat')); % culculated results

xlin = D3(end,1)*1.6;
% xlin=850
K = A3(:,5);

%%
global md 
parameter(id)
control()
h = md.h;
patientNames = md.patientNames;
ylin = max(max(D3(:,2)),max(A3(:,5)));
% set(gcf,'outerposition',get(0,'screensize'));
% suptitle({char(patientNames(id))});


subplot(223)
hold on
for i = 1:size(D3, 1)-1

%% Plot clinical PSA data
if D3(i, 3) == 1
    plot([D3(i,1),D3(i+1,1)] ,[D3(i,2), D3(i+1,2)], 'r', 'LineWidth',2, 'MarkerSize',25,'Marker','.');
else
    plot([D3(i,1),D3(i+1,1)] ,[D3(i,2), D3(i+1,2)],'Color',[0.549 0.549 0.549], 'LineWidth',2, 'MarkerSize',25,'Marker','.');
end

end

hold on;
% C6: K(1:317) = linspace(9,10.06,317);  
% C7: 
K(1:330) = linspace(0.45,0.4754,330);
plot(A3(:,1),K,'k','LineWidth',2);  %
hold on
clinicalPSA = plot([-3,-3],[-3,-3], 'r', 'MarkerSize',25,'Marker','.','LineWidth',2);
modeledPSA = plot([-3,-3],[-3,-3], 'k','LineWidth',3);

legend([clinicalPSA, modeledPSA],'Clinic PSA', 'Modeled PSA');

% --------------------------------------
% ����в�
t = floor(D3(:,1));
tdata_num = length(t);
yrealdata = D3(:,2);
ypinjun = sum(yrealdata)/tdata_num;

dataTimePoint = zeros(tdata_num,1);
ydata = zeros(tdata_num,1);
cancha = zeros(tdata_num,1);
totalcha = zeros(tdata_num,1);

for i = 1:tdata_num

dataTimePoint(i) = 1 + t(i) /h;         % ѡ��ģ����������ݵ��ʱ���λ��
ydata(i) = A3(floor(dataTimePoint(i)),5);   % ģ�������PSA����
cancha(i) = ( yrealdata(i) - ydata(i) )^2; 
totalcha(i) = ( yrealdata(i) - ypinjun )^2;

end

SSE = sum(cancha);
SST = sum(totalcha);
R2 = 1 - SSE/SST;
txt = ['R^2 = ' num2str(R2)];
text(xlin*0.8,2*ylin/3,txt,'FontSize',10)

set(gca, 'FontSize', 12)
ylim([0  ylin*1.2])
xlim([0 xlin]) %
xlabel('Days', 'FontSize', 12)
ylabel('PSA (nM)', 'FontSize', 12)
title('Patient C007')
box on


%% %%%%%%%%%%%%%%%%

for id = 22

% PatientData = load(strcat('data/patient-',num2str(id),'.dat')); % origial data
% u = U(PatientData);
D4=load(strcat('data/patient-',num2str(id),'.dat')); % origial data
A4=load(strcat('output/A/mdA-',num2str(id),'.dat')); % culculated results

xlin = D4(end,1)*1.6;
% xlin=850
K = A4(:,5);

%%
global md 
parameter(id)
control()
h = md.h;
patientNames = md.patientNames;
ylin = max(max(D(:,2)),max(A(:,5)));
% set(gcf,'outerposition',get(0,'screensize'));
% suptitle({char(patientNames(id))});


subplot(224)
%subtitle('C009')
hold on
for i = 1:size(D, 1)-1

%% Plot clinical PSA data
if D4(i, 3) == 1
    plot([D4(i,1),D4(i+1,1)] ,[D4(i,2), D4(i+1,2)], 'r', 'LineWidth',2, 'MarkerSize',25,'Marker','.');
else
    plot([D4(i,1),D4(i+1,1)] ,[D4(i,2), D4(i+1,2)],'Color',[0.549 0.549 0.549], 'LineWidth',2, 'MarkerSize',25,'Marker','.');
end

end

hold on;
% C6: K(1:317) = linspace(9,10.06,317);  C7: K(1:330) = linspace(0.45,0.4754,330);
plot(A4(:,1),K,'k','LineWidth',2);  %
hold on
clinicalPSA = plot([-3,-3],[-3,-3], 'r', 'MarkerSize',25,'Marker','.','LineWidth',2);
modeledPSA = plot([-3,-3],[-3,-3], 'k','LineWidth',3);

legend([clinicalPSA, modeledPSA],'Clinic PSA', 'Modeled PSA');

% --------------------------------------
% ����в�
t = floor(D4(:,1));
tdata_num = length(t);
yrealdata = D4(:,2);
ypinjun = sum(yrealdata)/tdata_num;

dataTimePoint = zeros(tdata_num,1);
ydata = zeros(tdata_num,1);
cancha = zeros(tdata_num,1);
totalcha = zeros(tdata_num,1);

for i = 1:tdata_num

dataTimePoint(i) = 1 + t(i) /h;         % ѡ��ģ����������ݵ��ʱ���λ��
ydata(i) = A4(floor(dataTimePoint(i)),5);   % ģ�������PSA����
cancha(i) = ( yrealdata(i) - ydata(i) )^2; 
totalcha(i) = ( yrealdata(i) - ypinjun )^2;

end

SSE = sum(cancha);
SST = sum(totalcha);
R2 = 1 - SSE/SST;
txt = ['R^2 = ' num2str(R2)];
text(xlin*0.8,2*ylin/3,txt,'FontSize',10)

set(gca, 'FontSize', 12)
ylim([0  ylin*1.2])
xlim([0 xlin]) %
xlabel('Days', 'FontSize', 12)
ylabel('PSA (nM)', 'FontSize', 12)
title('Patient C009')
box on

end
end