
%% Plotting the Figure 1 that x = a_12; y = a_21; z = RMSE
%
function PlotResult()

Result = zeros(400,3);
index = 1;

for i = 1:20
    for j = 1:20
       
        SaveBox = load(strcat('results/Save/Save-',num2str(i*j),'.dat'));
        Result(index,3) = sum(SaveBox(:,6));
        Result(index,1:2) = [i,j];   % Result = [a_12,a_21,RMSE] is a matrix that 100 rows and 3 columns

        index = index + 1;
    end
end

% [m,n]=find(Result==min(Result(:,3)))
%% Save the matrix of Result = [RMSE,a_12,a_21]
% dlmwrite(strcat('Result','.dat' ), Result, '');
[m,n]=find(Result == min(Result(:,3)))
%% Reshape the matrix for plotting
X = reshape(Result(:,1),20,20);
Y = reshape(Result(:,2),20,20);
Z = reshape(Result(:,3),20,20);

%% Plotting the Figure 1               
figure
surf(X,Y,Z)
colorbar
xlabel('a_{12}');ylabel('a_{21}');zlabel('RMSE')


%% Save the Figure 1
% saveas(gcf, ['result/Save/' '1.png']);

end