
% A = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB]
% B = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB,u]
function PlotOptimalfit()
% close all
figure(1)
hold on
for id = 15
hold on
PatientData = load(strcat('data/patient-',num2str(id),'.dat')); % origial data
u = U(PatientData);
D=load(strcat('data/patient-',num2str(id),'.dat')); % origial data
A=load(strcat('output/A/mdA-',num2str(id),'.dat')); % culculated results

xlin = D(end,1)*1.6;
% xlin=850
K = A(:,5);

%%
global md par
parameter(id)
control()
h = md.h;
patientNames = md.patientNames;
ylin = max(max(D(:,2)),max(A(:,5)));

figure(1)
set(gcf,'outerposition',get(0,'screensize'));
subplot(221)
y11 = par.q_1.*A(:,6).^2./(par.q_2.^2 + A(:,6).^2); 
[~,yAmaxl] = max(A(:,6));
hold on
plot(A(1:yAmaxl,6),y11(1:yAmaxl),'r','LineWidth',2);

hold on
plot(A(yAmaxl:end,6),y11(yAmaxl:end),'g','LineWidth',2);

hold on
plot(A(yAmaxl,6),y11(yAmaxl),'k*');
xlabel('yA');
ylabel('����ϸ����ֳ��r');


subplot(222)
% plot(A(:,1),u,'r','LineWidth',2)
% xlim([0 xlin])
% xlabel('Days')
% ylabel('��ҩ����u')


subplot(223)
hold on
plot(A(:,1),A(:,6),'k','LineWidth',2);
plot(A(:,1),A(:,7),'r','LineWidth',2)
plot(A(:,1),A(:,8),'b','LineWidth',2)
xlim([0 xlin])
xlabel('Days')
legend('������','����R','DHT')


subplot(224)
plot(A(:,1),y11,'LineWidth',2)
xlim([0 xlin])
xlabel('Days')
ylabel('����ϸ����ֳ��r')

% saveas(gcf,['results/NumericalFit_results/'  char(patientNames(id)) 'A.png'])


% ------------------------------------------------------------------

figure(2);

set(gcf,'outerposition',get(0,'screensize'));
suptitle({char(patientNames(id))});


subplot(211)

hold on
for i = 1:size(D, 1)-1

%% Plot clinical PSA data
if D(i, 3) == 1
    plot([D(i,1),D(i+1,1)] ,[D(i,2), D(i+1,2)], 'r', 'LineWidth',2, 'MarkerSize',25,'Marker','.');
else
    plot([D(i,1),D(i+1,1)] ,[D(i,2), D(i+1,2)],'Color',[0.549 0.549 0.549], 'LineWidth',2, 'MarkerSize',25,'Marker','.');
end

end

hold on;
% C6: K(1:317) = linspace(9,10.06,317);  C7: K(1:330) = linspace(0.45,0.4754,330);
plot(A(:,1),K,'k','LineWidth',2);  %
hold on
clinicalPSA = plot([-3,-3],[-3,-3], 'r', 'MarkerSize',25,'Marker','.','LineWidth',2);
modeledPSA = plot([-3,-3],[-3,-3], 'k','LineWidth',3);

legend([clinicalPSA, modeledPSA],'Clinic PSA', 'Modeled PSA');

% --------------------------------------
% ����в�
t = floor(D(:,1));
tdata_num = length(t);
yrealdata = D(:,2);
ypinjun = sum(yrealdata)/tdata_num;

dataTimePoint = zeros(tdata_num,1);
ydata = zeros(tdata_num,1);
cancha = zeros(tdata_num,1);
totalcha = zeros(tdata_num,1);

for i = 1:tdata_num

dataTimePoint(i) = 1 + t(i) /h;         % ѡ��ģ����������ݵ��ʱ���λ��
ydata(i) = A(floor(dataTimePoint(i)),5);   % ģ�������PSA����
cancha(i) = ( yrealdata(i) - ydata(i) )^2; 
totalcha(i) = ( yrealdata(i) - ypinjun )^2;

end

RSS = sum(cancha);
TSS = sum(totalcha);
Rfang = 1 - RSS/TSS;
txt = ['R^2 = ' num2str(Rfang)];
text(xlin*0.8,2*ylin/3,txt)

set(gca, 'FontSize', 12)
ylim([0  ylin*1.2])
xlim([0 xlin]) %
xlabel('Time/days', 'FontSize', 12)
ylabel({'Patient PSA and'; 'Optimized Model Fit PSA'}, 'FontSize',12)
box on


subplot(212);
hold on;
plot(A(:,1),A(:,2),'b','LineWidth',2);
plot(A(:,1),A(:,3),'r','LineWidth',2);
ylim([0 1e4])
xlim([0 xlin])
xlabel('Time/days')
ylabel({'Virtual Patient Curve';'Drug-resistant cell density'})
set(gca,'FontSize', 12)
legend('Sensitive', 'Resistant')
% pause(1)
% saveas(gcf,['results/NumericalFit_results/'  char(patientNames(id)) 'B.png'])
end

end