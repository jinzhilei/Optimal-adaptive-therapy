%%
function Model_fitting()

I0 = load('Optimal_para/y0.dat');  
for id = 1:28
    
PatientData = load(strcat('data/patient-',num2str(id),'.dat')); % origial data
T = floor(PatientData(end,1));
% T = 1000;
y0 = initialzation(I0(id,2), I0(id,3), I0(id,4));
control()
global md
h = md.h;
u = U(PatientData);  % ԭʼ��ҩ����
A = SolveODE(T,y0, id,u);   

% dlmwrite(strcat('output/mdA-',num2str(id),'.dat'),A,' ');    

% nstep = length(0:h:T); 
% u1 = ones(nstep,1);        % ��ҩ������== 1��
% u2 = zeros(nstep,1);       % ��ҩ������== 0��
% B = load(strcat('output/B/mdB-',num2str(i),'.dat'));
% B = SolveODE(T,y0, i,u1);                               
%dlmwrite(strcat('output/B/mdB-',num2str(i+4),'.dat'),B,' ');  % ��ҩ������= 1
% C = SolveODE(T,y0, i,u2);   
% dlmwrite(strcat('output/C/mdC-',num2str(i),'.dat'),C,' ');  % ��ҩ������= 0��
% disp(i)
% 
% Rcell = B(:,3);
% % plot(B(:,1),B(:,3))
% n = length(Rcell);
% 
% out = zeros(n,1);
% P0 = zeros(n,1);
% 
% sigma_p = 5;
% yRm = 1300;
% 
% for j = 1:1:n
%     
% % Rcell(j)
% disp(num2str(j/100+1))
% P0(j) = 0.01/( 1+exp(-(Rcell(j)-yRm)/sigma_p) );
% a=[0 1];
% Prob=[P0(j) 1-P0(j)];
% out(j)=randsrc(1,1,[a;Prob]);
% 
% end
% A0 = length(find(out(:,1)==0));
% out(1:A0,2) = find(out(:,1)==0)/3000;
% A = out(1:182,2)
% end

%% ------------------------
xlin = PatientData(end,1)*1.6;
% xlin = 850
K = A(:,5);
D = PatientData;
%%
global par
parameter(id)
control()
h = md.h;
patientNames = md.patientNames;
ylin = max(max(D(:,2)),max(A(:,5)));

figure(1)
set(gcf,'outerposition',get(0,'screensize'));
subplot(221)
y11 = par.q_1.*A(:,6).^2./(par.q_2.^2 + A(:,6).^2); 
[~,yAmaxl] = max(A(:,6));
hold on
plot(A(1:yAmaxl,6),y11(1:yAmaxl),'r','LineWidth',2);

hold on
plot(A(yAmaxl:end,6),y11(yAmaxl:end),'g','LineWidth',2);

hold on
plot(A(yAmaxl,6),y11(yAmaxl),'k*');
xlabel('yA');
ylabel('����ϸ����ֳ��r');


subplot(222)
% plot(A(:,1),u,'r','LineWidth',2)
% xlim([0 xlin])
% xlabel('Days')
% ylabel('��ҩ����u')


subplot(223)
hold on
plot(A(:,1),A(:,6),'k','LineWidth',2);
plot(A(:,1),A(:,7),'r','LineWidth',2)
plot(A(:,1),A(:,8),'b','LineWidth',2)
xlim([0 xlin])
xlabel('Days')
legend('������','����R','DHT')


subplot(224)
plot(A(:,1),y11,'LineWidth',2)
xlim([0 xlin])
xlabel('Days')
ylabel('����ϸ����ֳ��r')

 saveas(gcf,['results/NumericalFit_results/'  char(patientNames(id)) 'A.png'])


% ------------------------------------------------------------------

figure(2);

set(gcf,'outerposition',get(0,'screensize'));
suptitle({char(patientNames(id))});


subplot(311)

hold on
for i = 1:size(D, 1)-1

%% Plot clinical PSA data
if D(i, 3) == 1
    plot([D(i,1),D(i+1,1)] ,[D(i,2), D(i+1,2)], 'r', 'LineWidth',2, 'MarkerSize',25,'Marker','.');
else
    plot([D(i,1),D(i+1,1)] ,[D(i,2), D(i+1,2)],'Color',[0.549 0.549 0.549], 'LineWidth',2, 'MarkerSize',25,'Marker','.');
end

end

hold on;
% C6: K(1:317) = linspace(9,10.06,317);  C7: K(1:330) = linspace(0.45,0.4754,330);
% for i = 1:16500
% K(i) = 1.25-1.25*(i-1)./16500 +K(i);
% end
% 4.605;
% linspace(1.25,10.06,317);
plot(A(:,1),K,'k','LineWidth',2);  %
hold on
clinicalPSA = plot([-3,-3],[-3,-3], 'r', 'MarkerSize',25,'Marker','.','LineWidth',2);
modeledPSA = plot([-3,-3],[-3,-3], 'k','LineWidth',3);

legend([clinicalPSA, modeledPSA],'Clinic PSA', 'Modeled PSA');

% --------------------------------------
% ����в�
t = floor(D(:,1));
tdata_num = length(t);
yrealdata = D(:,2);
ypinjun = sum(yrealdata)/tdata_num;

dataTimePoint = zeros(tdata_num,1);
ydata = zeros(tdata_num,1);
cancha = zeros(tdata_num,1);
totalcha = zeros(tdata_num,1);

for i = 1:tdata_num

dataTimePoint(i) = 1 + t(i) /h;         % ѡ��ģ����������ݵ��ʱ���λ��
ydata(i) = K(floor(dataTimePoint(i)));   % ģ�������PSA����
cancha(i) = ( yrealdata(i) - ydata(i) )^2; 
totalcha(i) = ( yrealdata(i) - ypinjun )^2;

end

RSS = sum(cancha);
TSS = sum(totalcha);
Rfang = 1 - RSS/TSS;
txt = ['R^2 = ' num2str(Rfang)];
text(xlin*0.8,2*ylin/3,txt)

set(gca, 'FontSize', 12)
ylim([0  ylin*1.2])
xlim([0 xlin]) %
xlabel('Time/days', 'FontSize', 12)
ylabel({'Patient PSA and'; 'Optimized Model Fit PSA'}, 'FontSize',12)
box on


subplot(312);
hold on;
plot(A(:,1),A(:,2),'b','LineWidth',2);
plot(A(:,1),A(:,3),'r','LineWidth',2);
ylim([0 1e4])
xlim([0 xlin])
xlabel('Time/days')
ylabel({'Virtual Patient Curve';'Drug-resistant cell density'})
set(gca,'FontSize', 12)
legend('Sensitive', 'Resistant')
% pause(1)
% saveas(gcf,['results/NumericalFit_results/'  char(patientNames(id)) 'B.png'])

subplot(313)
plot(A(:,1),A(:,3),'r')
end
end



