%% Give Alternative Treatments

% Load Patient Data
load('TrialPatientData.mat')

% Load optimized parameters [yS(0), yR(0), alpha_RS, beta_SC]
load('optimizedModelFits.mat')

% Create patient name vector
patientNames = {'P1001', 'P1002', 'P1003', 'P1004', 'P1005', 'P1006', 'P1007', 'P1009', 'P1010', 'P1011', 'P1012', 'P1014', 'P1015', 'P1016', 'P1017', 'P1018', 'P1020', ' C001', ' C002', ' C003', ' C004', ' C005', ' C006', ' C007', ' C008', ' C009', ' C010', ' C011', ' C012', ' C013', ' C014', ' C015'};
% size(patientNames, 2)
close all
for patientIndex = 1
    disp(patientIndex)
    
    % Extract data from named patient data
    patientName = char(patientNames(patientIndex));
    data = eval(patientName);
    
    % Create time vectors
    t = 1:1:floor(data(end,1));
    t_max = max(t);
    
    % Create vector u from patient data
    u_original = createU(data(:,1), data(:,3));
    
    % Extract all optimized parameters [yS(0), yR(0), alpha_RS, beta_SC]
    optimizationParams = optimizedModelFits(patientIndex, :);
    
    % Solve with original
    [yS_original, yR_original, modeledPSA_original] = solveSRODE(optimizationParams, t_max, u_original);
    
    % Extract time of first abiraterone administration
    t_firstAbi = find(u_original == 1, 1, 'first');
    
    %% Give SOC
    % Clear our variables
%     clear yS_NewSOC yR_NewSOC modeledPSA_NewSOC u_newSOC t_newSOC
%     
%     % Run and plot with SOC
%     [yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC, u_newSOC, t_newSOC] = solveSRODE_SOC(optimizationParams, t_max, t_firstAbi);
%     PlotAlternateTreatmentsFunction(patientName, data, t, u_original, yS_original, yR_original, modeledPSA_original, t_newSOC, u_newSOC, yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC)
%      
%      %Save 
% %      savename = ['../results/PatientFigures/AlternateTreatment_SOC/' char(patientNames(patientIndex)) '_SOC.png'];
% %      saveas(gcf, savename)
% %      pause(1.0)
%      close(gcf)
    
    %% Give IAT
    % Clear our variables
%     clear yS_NewSOC yR_NewSOC modeledPSA_NewSOC u_newSOC t_newSOC
%     
%     % Run and plot with IAT
%     [yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC, u_newSOC, t_newSOC] = solveSRODE_IAT(optimizationParams, t_max, t_firstAbi);
%     PlotAlternateTreatmentsFunction(patientName, data, t, u_original, yS_original, yR_original, modeledPSA_original, t_newSOC, u_newSOC, yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC)
    
%     savename = ['../results/PatientFigures/AlternateTreatment_IAT/' char(patientNames(patientIndex)) '_IAT.png'];
%     saveas(gcf, savename)
%     pause(1.0)
%     close(gcf)
    
    %% Give Adaptive
    % Clear our variables
 %   clear yS_NewSOC yR_NewSOC modeledPSA_NewSOC u_newSOC t_newSOC
    
    % Run and plot with Adaptive
    adaptivePercent = 0.5;
     [yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC, u_newSOC, t_newSOC] = solveSRODE_Adaptive(optimizationParams, t_max, t_firstAbi, adaptivePercent);
     %PlotAlternateTreatmentsFunction(patientName, data, t, u_original, yS_original, yR_original, modeledPSA_original, t_newSOC, u_newSOC, yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC)

     
%      savename = ['../results/PatientFigures/AlternateTreatment_Adaptive/' char(patientNames(patientIndex)) '_ADAPTIVE.png'];
%      saveas(gcf, savename)
%      pause(1.0)
%      close(gcf)
figure(3)
title('Patient P1001')

linewidth = 1.6;
T = dir(strcat('output/',num2str(patientIndex),''));
Tm = 2000;
xlin = 0;
% K0 = 10000;
% P = [u, Y, J] = [u,  ys,yr,yP,  yPS,yA,yR,  yD,yTS, J]

for i = 1:Tm   % 18 21 need   % 17 19 very no 
P((i-1)*100+1:i*100,:) = load(strcat('output/',num2str(patientIndex),'/Treatment-A',num2str(i),'.dat'));
% [u, Y, J] = [u,  ys,yr,yP,  yPS,yA,yR,  yD,yTS, J]
end

A = zeros(Tm,1);
for i = 1:Tm
    A(i,1) = P((i-1)*100+1,1);
end

n = floor(Tm/7);
B = zeros(n,7);
for i = 1:n
    for j = 1:7
        B(i,j) = A(7*(i-1)+j,1);
    end
end
% down data for drawing, in units of 7 days
 % dlmwrite(strcat('Optimal_treatment/Treatment_data/',num2str(patientIndex),'B.dat'),B,' ')

hold on
% 
% A = suptitle(strcat('Patient P100',num2str(patientIndex))); 
% set(gcf,'outerposition',get(0,'screensize'))
% set(A,'FontSize',12)
% set (gcf,'position', [50,50,1200,600]);

subplot(321)
hold on        

% My
plot(0.01:0.01:Tm,P(:,5)/max(P(:,5)),'r', 'LineWidth',linewidth)
hold on

hold on
% Gatenby
maxPSAforScaling = max(modeledPSA_original);
modeledPSA_original = modeledPSA_original./maxPSAforScaling;
modeledPSA_NewSOC = modeledPSA_NewSOC./maxPSAforScaling;
plot(t_newSOC ,modeledPSA_NewSOC,'b-.', 'LineWidth',linewidth);

% data
D = load(strcat('output/A/mdA-',num2str(patientIndex),'.dat'));
plot(D(:,1) , D(:,5)/max(D(:,5)), 'g:','LineWidth',linewidth);


hold on
%legend('Our Therapeutic Framework','Gatenby et al.(2022)')   
title('(a)')
xlim([xlin,Tm])
xlabel('Days');
ylabel('PSA (ng/ml)');
legend('AT- BLO','AT50','AT-Clinical')
ylim([0,3])
box on
set(gca, 'FontSize', 12);




subplot(323)

hold on
plot(t_newSOC, yS_NewSOC, 'b-.', 'LineWidth',linewidth);
hold on
plot(D(:,1) , D(:,2), 'g:','LineWidth',linewidth);
hold on
plot(0.01:0.01:Tm,(P(:,2)),'r', 'LineWidth',linewidth)
title('(b)')
xlim([xlin,Tm])
ylim([0,6000])
xlabel('Days');
ylabel('Sensitive cells');
box on
set(gca, 'FontSize', 12);



subplot(325)
% yyaxis left
plot(t_newSOC, yR_NewSOC, 'b-.', 'LineWidth',linewidth);
hold on
plot(D(:,1) , D(:,3), 'g','LineStyle',':','LineWidth',linewidth);
hold on
% ylim([0,7800])
% 'Color',[0.12, 0.56, 1],

% yyaxis right
plot(0.01:0.01:Tm,(P(:,3)),'r', 'LineWidth',linewidth);
% ylim([0,1200])
ylabel('Resistant cells')

title('(c)')
xlim([xlin,Tm])
ylim([0,10000])
xlabel('Days');
ylabel('Resistant cells');
set(gca, 'FontSize', 12);
box on

end



for patientIndex = 16
    disp(patientIndex)
    
    % Extract data from named patient data
    patientName = char(patientNames(patientIndex));
    data = eval(patientName);
    
    % Create time vectors
    t = 1:1:floor(data(end,1));
    t_max = max(t);
    
    % Create vector u from patient data
    u_original = createU(data(:,1), data(:,3));
    
    % Extract all optimized parameters [yS(0), yR(0), alpha_RS, beta_SC]
    optimizationParams = optimizedModelFits(patientIndex, :);
    
    % Solve with original
    [yS_original, yR_original, modeledPSA_original] = solveSRODE(optimizationParams, t_max, u_original);
    
    % Extract time of first abiraterone administration
    t_firstAbi = find(u_original == 1, 1, 'first');
    
    %% Give SOC
    % Clear our variables
%     clear yS_NewSOC yR_NewSOC modeledPSA_NewSOC u_newSOC t_newSOC
%     
%     % Run and plot with SOC
%     [yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC, u_newSOC, t_newSOC] = solveSRODE_SOC(optimizationParams, t_max, t_firstAbi);
%     PlotAlternateTreatmentsFunction(patientName, data, t, u_original, yS_original, yR_original, modeledPSA_original, t_newSOC, u_newSOC, yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC)
%      
%      %Save 
% %      savename = ['../results/PatientFigures/AlternateTreatment_SOC/' char(patientNames(patientIndex)) '_SOC.png'];
% %      saveas(gcf, savename)
% %      pause(1.0)
%      close(gcf)
    
    %% Give IAT
    % Clear our variables
%     clear yS_NewSOC yR_NewSOC modeledPSA_NewSOC u_newSOC t_newSOC
%     
%     % Run and plot with IAT
%     [yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC, u_newSOC, t_newSOC] = solveSRODE_IAT(optimizationParams, t_max, t_firstAbi);
%     PlotAlternateTreatmentsFunction(patientName, data, t, u_original, yS_original, yR_original, modeledPSA_original, t_newSOC, u_newSOC, yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC)
    
%     savename = ['../results/PatientFigures/AlternateTreatment_IAT/' char(patientNames(patientIndex)) '_IAT.png'];
%     saveas(gcf, savename)
%     pause(1.0)
%     close(gcf)
    
    %% Give Adaptive
    % Clear our variables
 %   clear yS_NewSOC yR_NewSOC modeledPSA_NewSOC u_newSOC t_newSOC
    
    % Run and plot with Adaptive
    adaptivePercent = 0.5;
     [yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC, u_newSOC, t_newSOC] = solveSRODE_Adaptive(optimizationParams, t_max, t_firstAbi, adaptivePercent);
     %PlotAlternateTreatmentsFunction(patientName, data, t, u_original, yS_original, yR_original, modeledPSA_original, t_newSOC, u_newSOC, yS_NewSOC, yR_NewSOC, modeledPSA_NewSOC)

     
%      savename = ['../results/PatientFigures/AlternateTreatment_Adaptive/' char(patientNames(patientIndex)) '_ADAPTIVE.png'];
%      saveas(gcf, savename)
%      pause(1.0)
%      close(gcf)
patientIndex1 = 13;
linewidth = 1.6;
T = dir(strcat('output/',num2str(patientIndex1),''));
Tm = 2000;
xlin = 0;
% K0 = 10000;
% P = [u, Y, J] = [u,  ys,yr,yP,  yPS,yA,yR,  yD,yTS, J]

for i = 1:Tm   % 18 21 need   % 17 19 very no 
P((i-1)*100+1:i*100,:) = load(strcat('output/',num2str(patientIndex1),'/Treatment-A',num2str(i),'.dat'));
% [u, Y, J] = [u,  ys,yr,yP,  yPS,yA,yR,  yD,yTS, J]
end

A = zeros(Tm,1);
for i = 1:Tm
    A(i,1) = P((i-1)*100+1,1);
end

n = floor(Tm/7);
B = zeros(n,7);
for i = 1:n
    for j = 1:7
        B(i,j) = A(7*(i-1)+j,1);
    end
end
% down data for drawing, in units of 7 days
 % dlmwrite(strcat('Optimal_treatment/Treatment_data/',num2str(patientIndex),'B.dat'),B,' ')


hold on
% 
% A = suptitle(strcat('Patient P100',num2str(patientIndex))); 
% set(gcf,'outerposition',get(0,'screensize'))
% set(A,'FontSize',12)
% set (gcf,'position', [50,50,1200,600]);

subplot(322)
hold on

% My
plot(0.01:0.01:Tm,P(:,5)/max(P(:,5)),'r', 'LineWidth',linewidth)

hold on     

% Gatenby
maxPSAforScaling = max(modeledPSA_original);
modeledPSA_original = modeledPSA_original./maxPSAforScaling;
modeledPSA_NewSOC = modeledPSA_NewSOC./maxPSAforScaling;
plot(t_newSOC ,modeledPSA_NewSOC,'b-.', 'LineWidth',linewidth);

hold on

% data
D1 = load(strcat('output/A/mdA-',num2str(patientIndex1),'.dat'));
plot(D1(:,1) , D1(:,5)/max(D1(:,5)), 'g:','LineWidth',linewidth);
hold on       
   
title('(d)')
xlim([xlin,Tm])
xlabel('Days');
ylabel('PSA (ng/ml)');
ylim([0,3])
box on
set(gca, 'FontSize', 12);




subplot(324)
hold on
plot(t_newSOC, yS_NewSOC, 'b-.', 'LineWidth',linewidth);
hold on
plot(D1(:,1) , D1(:,2), 'g:','LineWidth',linewidth);
hold on
plot(0.01:0.01:Tm,(P(:,2)),'r', 'LineWidth',linewidth)
title('(e)')
xlim([xlin,Tm])
ylim([0,6000])
xlabel('Days');
ylabel('Sensitive cells');
box on
set(gca, 'FontSize', 12);



subplot(326)
% yyaxis left
plot(t_newSOC, yR_NewSOC, 'b-.', 'LineWidth',linewidth);
hold on
plot(D1(:,1) , D1(:,3), 'g:','LineWidth',linewidth);
hold on

% yyaxis right
plot(0.01:0.01:Tm,(P(:,3)),'r', 'LineWidth',linewidth)
% ylim([0,5000])
ylabel('Resistant cells')

title('(f)')
xlim([xlin,Tm])
ylim([0,10000])
xlabel('Days');
ylabel('Resistant cells');
box on    
set(gca, 'FontSize', 12);

X = imsharpen(figure(3));
imshow(X)
end

