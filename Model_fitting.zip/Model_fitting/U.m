%
%% using clinical patient data, Complete missing patient data 
function y = U(PatientData)

close all;
global md
control();
h = md.h;

t = PatientData(:,1);
n = size(t,1);
tm = round(PatientData(end,1));
u = zeros(tm,1);

z = 0:h:tm;
y = zeros(size(z,2),1);
for i = 1:1:n-1
    u( round(t(i))+1: round(t(i+1)) ) = PatientData(i,3);
end
for j = 1:1:tm
    y((j-1)*100+1:j*100 ) = cal(u(j));
end
end


%% Simulate the drug decay process
function y = cal(u)

close all;
global md
control();
h = md.h;

for i = 1:1:1  % (i-1)/0.01+1:i/h+1
    f = @(t,y)-(log(2)/0.3742)*y; % dy/dt = -a*y; 'a' represents the rate of drug decay
    [t((i-1)/h+1:i/h+1),y((i-1)/h+1:i/h+1)] = ode45(f,i-1:h:i,u(i));
end
    n = length(y); 
for j = 1:n
   if y(j) <= 0
       y(j) = 0;
   else 
       y(j) = y(j);
   end
end
y = y(1:100);
end
