
function findtotalRMSE(a_12, a_21, fid)
        
A = zeros(28,9);
totalRMSE = 0;
      
    for PatientIndex = 1:28

       D = load(strcat('data/patient-',num2str(PatientIndex),'.dat')); % origial data
       T = D(end,1);
       u = U(D);

       % Send in extra parameters
       f = @(optim_par)CamputeRMSE(optim_par, D, T, PatientIndex, u, a_12, a_21);

       % Guess initial composition
       alphaguess = 1 + rand(1)*49;
       a_mutguess = rand(1)*1e-4;
       yPSA0guess = 1 + rand(1)*9;
       ys0guess = 1 + rand(1)*9999;
       yr0guess = 1 + rand(1)*9999;
       
       % Form initial guess vector 
       initialGuess = [alphaguess, a_mutguess, yPSA0guess,ys0guess,yr0guess];

       %   alpha   a_mut   PSA(0)   ys0    yr0
       lb = [1      0       0       1       1];
       ub = [8e2    1e-4    200     1e4     1e4];

       options = optimoptions(@fmincon, 'Display', 'none');

       % Run optimal control to find optimized yS and yR.
       [optimal_par, RMSE] = fmincon(f, initialGuess, [], [], [], [], lb, ub, [], options);  %

       % Save each patinet and each replicate [RMSE, y(0):sensitive, y(0):resistant] 
       totalRMSE = totalRMSE + RMSE;

       A(PatientIndex,:) = [PatientIndex,a_12,a_21,optimal_par(1:5),RMSE];

    end
            
 dlmwrite(strcat('result/Save-',num2str(fid),'.dat'),A,' ');

end