
%% Simulate the drug decay process
function y = cal(u)

global md
control();
h = md.h;

for i = 1:1:1  % (i-1)/0.01+1:i/h+1
                            % dy/dt = -a*y; 'a' represents the rate of drug decay
f = @(t,y)-(log(2)/0.3742)*y; % because of the half-life is 8.92hours = 8.92/24 day = 0.3742day ,so the decay rate is log(2)/0.3742 day^{-1}
[t((i-1)/h+1:i/h+1),y((i-1)/h+1:i/h+1)] = ode45(f,i-1:h:i,u(i));

n = length(y); 
for j = 1:n
   if y(j) <= 0
       y(j) = 0;
   else 
       y(j) = y(j);
   end
end
end
y = y(1:100);
end
