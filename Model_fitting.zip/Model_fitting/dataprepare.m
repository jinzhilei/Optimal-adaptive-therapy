
function dataprepare()

% % Load Patient PSA and Abi Data
% load('G:\Model_code\Wang_model\data\TrialPatientData.mat')
% % Load optimized parameters [yS(0), yR(0)]
% load('G:\Model_code\Wang_model\code\data\optimitalFit.mat')
% % Create patient name vector
n=28;

[id, name]=textread('data/patientlist.csv','%d,%s');

I0=zeros(n,3);

for i=1:n
    j=id(i);
    patientName = char(name(j)); 
    data = eval(patientName);  % �������ڵ��ַ�����Ϊ��䲢����    
    dlmwrite(strcat('data/patient-',num2str(j),'.dat'),data,' ');
    
    J = optimitalFit(j, :);
    I0(i,1)=j;
    I0(i,2)= J(1);
    I0(i,3)= J(2);
end

dlmwrite('data/cellini.dat',I0,' ');

end