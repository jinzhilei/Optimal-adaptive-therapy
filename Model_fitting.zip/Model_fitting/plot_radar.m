%%
function plot_radar()
close all;clc;clear all;

X=[1.1 		0.1	1.42		0.1		1.2		5		0.043		0.11		0.15		0.01		0.022;
   1.8958929	1.3	2.8885714	2.261071429	3.458214286	5.928571429	1.2638		2.80631		3.5552143	1.7716		4.44382;
    4.33		8	4.7		6		14		6		11		9		20		10.6		7.826];
RC=radarChart(X,'Type','Patch');
RC=RC.draw();
RC.legend();

colorList=[184 168 207;
          138 140 191;
          78 101 155;
          231 188 198;
          253 207 158;
          239 164 132;
          182 118 108]./255;
for n=1:RC.ClassNum
    RC.setPatchN(n,'FaceColor',colorList(n,:),'EdgeColor',colorList(n,:))
end

end
