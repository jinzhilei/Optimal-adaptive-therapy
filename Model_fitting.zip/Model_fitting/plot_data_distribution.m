%% Parameter distribution

function plot_data_distribution()
figure(1)
subplot(331)
axis tight
set(gca,'position',[1.58 1.06 41 41.13])
x = [0.0110
0.0120 
0.0140 
0.0160 
0.0170 
0.0180 
0.0200 
0.0220
0.0231 
0.0315 
0.0350 
0.0433 ];
y = [0.0714
0.1429
0.1429
0.1429
0.0714
0.0714
0.0714
0.0714
0.1071
0.0357
0.0357
0.0357];
bar(x,y)
ylabel('Frequency','fontsize',12)
xlabel('r_2','fontsize',12);
title('(A)')
set(gca,'FontSize',12)

hold on
subplot(332)
 x2 = [0.0002 
0.0004 
0.0010 
0.0012
0.0017 
0.0020 
0.0030 
0.0050 
0.0080];
 y2 = [0.2142
0.0714
0.5
0.0714
0.0357
0.0357
0.0357
0.0357
0.0357];
bar(x2,y2)
ylabel('Frequency','fontsize',12)
xlabel('d_2','fontsize',12);
title('(B)')
set(gca,'FontSize',12)

subplot(333)
x3 = [0.0142 
0.0170 
0.0210 
0.0230 
0.0240 
0.0250 
0.0273 
0.0286 
0.0330 
0.0350 
0.0380 
0.0440 
0.0470];
y3 = [0.0714
0.0714
0.0714
0.0714
0.1071
0.0357
0.1071
0.0714
0.1071
0.0714
0.1429
0.0357
0.0357];
bar(x3,y3)
ylabel('Frequency','fontsize',12)
xlabel('q_1','fontsize',12);
title('(C)')
set(gca,'FontSize',12)

subplot(334)
x5 = [1.2
2
2.8
3
4
4.5
5
10];
y5 = [0.0357
0.3929
0.0357
0.1429
0.1786
0.0357
0.1429
0.0357];
bar(x5,y5)
ylabel('Frequency','fontsize',12)
xlabel('q_3','fontsize',12);
title('(D)')
set(gca,'FontSize',12)


subplot(335)
x7 = [3.3000 
12.0000 
20.0000 
28.0000 
35.0000 
40.0000 
47.0000 
57.0000 
64.0000 
76.0000 
85.0000 
120
131.0000 
180.0000 
200.0000 
210
270.0000 ];
y7 = [0.0714
0.0357
0.1429
0.0357
0.0714
0.0357
0.0714
0.0357
0.0357
0.0714
0.0714
0.0714
0.0714
0.0357
0.0714
0.0357
0.0357];
bar(x7,y7)
ylabel('Frequency','fontsize',12)
xlabel('��','fontsize',12);
title('(E)')
set(gca,'FontSize',12)

subplot(336)
x8 = [2.20E-07
4.09E-06
3.13E-05
4.18E-05
4.50E-05
4.77E-05
5.00E-05
6.32E-05];
y8 = [0.0357
0.0714
0.1071
0.0357
0.1786
0.0714
0.3929
0.1071];
bar(x8,y8)
ylabel('Frequency','fontsize',14)
xlabel('��_{mut}','fontsize',14);
title('(F)')
set(gca,'FontSize',12)


%%
%figure(2)
subplot(337)
x9 = [0.00000088
0.0000012
0.000003
0.000005
0.00001
0.000016
0.000022
0.00003
0.000035];
y9 = [2
1
5
3
4
3
4
4
3];
bar(x9,y9)
ylabel('Frequency','fontsize',14)
xlabel('��_p','fontsize',14);
title('(G)')
set(gca,'FontSize',14)

subplot(338)
x10 = [0.0015
0.0028
0.0035
0.01
0.011
0.012
0.014
0.016
0.018
0.02
0.022
0.023
0.026
0.038
0.055];
y10 = [1
1
1
1
1
8
1
1
3
1
1
1
1
1
5];
bar(x10,y10)
ylabel('Frequency','fontsize',14)
xlabel('��_1','fontsize',14);
title('(H)')
set(gca,'FontSize',14)

subplot(339)
x11 = [0.5
10
18.7
25
40
50
62
70
89
100
117
130
140
160
330];
y11 = [1
1
2
3
5
4
1
1
1
3
1
1
1
1
2];
bar(x11,y11)
ylabel('Frequency','fontsize',12)
xlabel('��_2','fontsize',12);
title('(I)')
set(gca,'FontSize',14)


end