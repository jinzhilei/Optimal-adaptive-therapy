%% TTP in days
function survival_curves()
figure()
CT_Clinical = [96 0;
120	0;
126	0;
195	0;
210	0;
270	0;
270	0;
414	0;
444	0;
450	0;
519	0;
531	0;
588	0;
750	0;
780	0;
943.5 0];
CT_Our_Index = [118.731	0;
132.231	0;
141.039	0;
212.151	0;
231.621	0;
251.289	0;
261.489	0;
388.101	0;
392.661	0;
466.2	0;
499.281	0;
508.17	0;
581.58	0;
728.421	0;
753.621	0;
873.741	0];


AT_Clinical = [321	0;
324	0;
330	0;
600	0;
903	0;
909	0;
918	0;
942	0;
1065	0;
1140	0;
1284	0;
1593	0;
2100	1;
2100	1;
2100	1;
2100	1];

AT_Our_Index = [287	0;
290	0;
309	0;
649	0;
738	0;
745	0;
822	0;
890	0;
908	0;
939	0;
2100	1;
2100	1;
2100	1;
2100	1
1094	0;
1396	0];
%% Calculate median
medianAdaptive = median(AT_Clinical(:,1));
medianControl = median(CT_Clinical(:,1));

%% Use kmplot to plot
subplot(221)
title('(A)')
kmplot(CT_Clinical)
hold on
kmplot(CT_Our_Index)
legend('CT- Clinical','Fitted under indicator')
% legendAdaptive1 = plot([-1,-1],[-1,-1], 'r', 'LineWidth', 3);
% legendControl1 = plot([-1,-1],[-1,-1], 'b', 'LineWidth', 3);
% legendCensored1 = plot(-1, -1, 'k', 'LineStyle', 'none', 'Marker', 'x', 'MarkerSize', 9);
hold off

subplot(222)
title('(B)')
c1 = kmplot(AT_Clinical);
hold on
c2 = kmplot(AT_Our_Index);
legend('AT- Clinical','Fitted under indicator')
% S3=plot([medianAdaptive medianAdaptive],[0.5176 0],'k:');
% S4=plot([medianControl medianControl],[0.5 0],'k:');
% 
% legendAdaptive = plot([-1,-1],[-1,-1], 'r', 'LineWidth', 3);
% legendControl = plot([-1,-1],[-1,-1], 'b', 'LineWidth', 3);
% legendCensored = plot(-1, -1, 'k', 'LineStyle', 'none', 'Marker', 'x', 'MarkerSize', 9);

%legend([legendControl, legendAdaptive, legendCensored], {'Control' 'Adaptive' 'Censored' })
end
