%% TTP in days
function compare_curves()

CT_Our_Index = [118.731	0;
132.231	0;
141.039	0;
212.151	0;
231.621	0;
251.289	0;
261.489	0;
388.101	0;
392.661	0;
466.2	0;
499.281	0;
508.17	0;
581.58	0;
728.421	0;
753.621	0;
873.741	0];

AT_Our_Index = [287	0;
290	0;
309	0;
649	0;
738	0;
745	0;
822	0;
890	0;
908	0;
939	0;
2100	1;
2100	1;
2100	1;
2100	1
1094	0;
1396	0];

AT50 = [50	0;
130	0;
311	0;
340	0;
848	0;
1233	0;
1314	0;
1344	0;
1370	0;
1507	0;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1];

% 6 10 14 15 17 22 23 24 27
AT_BLO = [410.52	0; % C011 24
516.29	0;             % C014 27
1300	0;             % C009 22
1606.08	0;             % C010 23
1786.3	0;             % C004 17
1820	0;             % P1010 6
1924.3	0;             % C003 15
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1;
2100	1];
%% Calculate median
% medianAdaptive = median(AT_Clinical(:,1));
% medianControl = median(CT_Clinical(:,1));

%% Use kmplot to plot
subplot(221)
title('(A)')
kmplot(CT_Our_Index)
hold on
kmplot(AT_Our_Index)
hold on
kmplot(AT50)
hold on
kmplot(AT_BLO)

legend('CT- Clinical','AT- Clinical','AT50','AT- DLO')
% legendAdaptive1 = plot([-1,-1],[-1,-1], 'r', 'LineWidth', 3);
% legendControl1 = plot([-1,-1],[-1,-1], 'b', 'LineWidth', 3);
% legendCensored1 = plot(-1, -1, 'k', 'LineStyle', 'none', 'Marker', 'x', 'MarkerSize', 9);
set(gca, 'Box', 'off', ...                                         % �߿�
         'LineWidth', 1,...                                     % �߿�
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % С�̶�
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1])             % ��������ɫ
     
% set(gca, 'FontSize', 12,'FontWeight','bold')
set(gca, 'FontSize', 12)
hold off


subplot(222)
B = 0;

id = 1;
Tm = 1750;
for i = 1:Tm
b = load(strcat('output/',num2str(id),'/Treatment-A',num2str(i),'.dat'));
B = B + b(1,1);
end

A = [733.0248	1025;
659.8584	875;
1079.5865	1166.666;
644.9087	925.9655;
1180.539	1310.8929;
426.5389	1705;
764.9467	990.0882;
249.5793	973.7037;
1136.523	1278.25;
1091.798	1270.2143;
700.7432	985.2632;
175.2959	975;
669.6454	1625;
1038.794	1150;
767.4662	900;
611.44634	1040;
635.03046	1250;
1001.535	1275;%%
1118.572	1250;
1040.966	1207.0455;%%
738.6573	880;
489.8297	765;
501.2458	775;
1012.966	1045;
913.5846	1050;
1158.023	1360
1007.417	1134;
1141.851	1550];

M = size(A,1);
g1 = repmat({'AT- DLO'},M,1);
% g3 = repmat({'MTD'},M,1);
g2 = repmat({'AT50'},M,1);
g = [g1;g2];
h = boxplot(A,g);
hold on;
B0(1:28,1) = 0.17*rand(28,1)+0.915;
B0(1:28,2) = 0.17*rand(28,1)+1.915;
plot(B0(:,1),A(:,1),'r.', 'MarkerSize',12)
hold on;
plot(B0(:,2),A(:,2), 'r.','MarkerSize',12)
hold on;
% plot(3,A(:,3), 'r.','MarkerSize',12)
set(h,'LineWidth',2)
hYLabel = ylabel('Cv1 (g)');
hXLabel = xlabel('Patient ID');

% ����������
set(gca, 'Box', 'off', ...                                              % �߿�
         'LineWidth', 1,...                                % �߿�
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % С�̶�
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1])             % ��������ɫ
% ������ֺ�
set(gca, 'FontName', 'Helvetica')
%set([hXLabel, hYLabel], 'FontName', 'AvantGarde')
set(gca, 'FontSize', 12)
%set([hXLabel, hYLabel], 'FontSize', 11,'FontWeight','bold')
% ������ɫ
set(gcf,'Color',[1 1 1])

% �߿�      
g1 = repmat({'P1'},M,1);
g2 = repmat({'P2'},M,1);
g3 = repmat({'P3'},M,1);
g4 = repmat({'P5'},M,1);
g5 = repmat({'P7'},M,1);
g6 = repmat({'P10'},M,1);
g7 = repmat({'P11'},M,1);
g8 = repmat({'P12'},M,1);
g9 = repmat({'P14'},M,1);
g10 = repmat({'P15'},M,1);
g11 = repmat({'P16'},M,1);
g12 = repmat({'P17'},M,1);
g13 = repmat({'P18'},M,1);
g14 = repmat({'C1'},M,1);
g15 = repmat({'C2'},M,1);
g16 = repmat({'C3'},M,1);
g17 = repmat({'C4'},M,1);
g18 = repmat({'C5'},M,1);
g19 = repmat({'C6'},M,1);
g20 = repmat({'C7'},M,1);
g21 = repmat({'C8'},M,1);
g22 = repmat({'C9'},M,1);
g23 = repmat({'C10'},M,1);
g24 = repmat({'C11'},M,1);
g25 = repmat({'C12'},M,1);
g26 = repmat({'C13'},M,1);
g27 = repmat({'C14'},M,1);
g28 = repmat({'C15'},M,1);
g = [g1; g2; g3;g4;g5;g6;g7;g8;g9;g10;g11;g12;g13;g14;g15;g16;g17;g18;g19;g20;g21;g22;g23;g24;g25;g26;g27;g28];


subplot(2,2,[3,4])
h(1) = plot(A(:,1),'r-o','LineWidth',1.5);
hold on
h(2) = plot(A(:,2),'b-*','LineWidth',1.5);
xticks(1.01.*[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28])
% xticks(1:2:84)
c = {'P1001','P1002','P1003','P1005','P1007','P1010','P1011','P1012','P1014','P1015','P1016','P1017','P1018','C001','C002','C003','C004','C005','C006','C007','C008','C009','C010','C011','C012','C013','C014','C015'};
xticklabels(c)
set(gca,'XTickLabelRotation',46)
% set(h11,'LineWidth',2)
hYLabel = ylabel('Cv1 (g)');
hXLabel = xlabel('Patient ID');
legend('AT- DLO','AT50','FontSize',10)

% ����������
set(gca, 'Box', 'off', ...                                         % �߿�
         'LineWidth', 1,...                                     % �߿�
         'XMinorTick', 'off', 'YMinorTick', 'off', ...            % С�̶�
         'XColor', [.1 .1 .1],  'YColor', [.1 .1 .1])             % ��������ɫ
% ������ֺ�
set(gca, 'FontName', 'Helvetica')
%set([hXLabel, hYLabel], 'FontName', 'AvantGarde')
set(gca, 'FontSize', 12)
% set([hXLabel, hYLabel], 'FontSize', 11,'FontWeight','bold')
% ������ɫ
set(gcf,'Color',[1 1 1])

end
