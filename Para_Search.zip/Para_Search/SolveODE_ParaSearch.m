%
% Solve the model, output the result
% G = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB]
%
function G = SolveODE_ParaSearch(optim_par,T, id,u,a_12,a_21)

global par md
parameter(id);
control();
h = md.h;
K = par.K;

y0 = [optim_par(4); optim_par(5);optim_par(3)*10; optim_par(3); 3140; 16; 15; 1.7336;0];

%% 
nstep = length(0:h:T);
G = zeros(nstep, 10);
t = 0;          % A = [t,ys,yr,  yP,yPS,yA,  yR,yD,yTS,  yB]
G(1,1) = t;

for i=1:9
    G(1,i+1) = y0(i);
end


for i = 2:nstep

    t = G(i-1,1);
    Y0 = G(i-1,2:10);
    k1 = Model_ParaSearch(Y0, u(i), optim_par(1) ,optim_par(2),a_12,a_21);
    k2 = Model_ParaSearch(Y0 + (h/2)*k1, u(i),optim_par(1), optim_par(2),a_12,a_21);
    k3 = Model_ParaSearch(Y0 + (h/2)*k2, u(i),optim_par(1) ,optim_par(2),a_12,a_21);
    k4 = Model_ParaSearch(Y0 + h*k3, u(i),optim_par(1) ,optim_par(2),a_12,a_21) ;
    
    Y1 = Y0 + (h/6)*(k1 + 2 * k2 + 2 * k3 + k4);
        
    Y1(1) = max(Y1(1) , 0);
    Y1(2) = max(Y1(2) , 0);
    
    Y1(1) = min(Y1(1) , K);
    Y1(2) = min(Y1(2) , K);
    
    Y1(3) = max(Y1(3),0);
    Y1(4) = max(Y1(4),0);   
       
    Y1(5)= max(Y1(5),0);
    Y1(6)= max(Y1(6),0);
    Y1(7)= max(Y1(7),0);
    Y1(8)= max(Y1(8),0);
    
    G(i,1) = t + h;
    G(i,2:10) = Y1;  

end


end


