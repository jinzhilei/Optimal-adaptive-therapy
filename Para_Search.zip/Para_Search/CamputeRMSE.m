
function [RMSE] = CamputeRMSE(optim_par, D, T, id, u,a_12,a_21)

global md
control()
h = md.h;

G = SolveODE_ParaSearch(optim_par, T, id, u,a_12,a_21);

t = D(:,1);
tdata_num = length(t);
yrealdata = D(:,2);

dataTimePoint = zeros(tdata_num,1);
ydata = zeros(tdata_num,1);
cancha = zeros(tdata_num,1);

for j = 1:tdata_num
    
    dataTimePoint(j) = 1 + t(j) /h;   % 
    ydata(j) = G( floor(dataTimePoint(j)), 5 );
    cancha(j) = ( yrealdata(j) - ydata(j) ).^2;
end

RMSE = sqrt( sum(cancha)./tdata_num );   

end



