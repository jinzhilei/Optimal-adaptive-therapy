
%  [ys,yr,yP,  yPS,yA,yR,  yD,yTS,yB]
function z = Model_ParaSearch(Y,u ,alpha,a_mut,a_12,a_21)

global par

ys = Y(1);
yr = Y(2);
yP = Y(3);
yPS = Y(4);
yA = Y(5);
yR = Y(6);
yD = Y(7);
yTS = Y(8);
yB = Y(9);

z=zeros(1,9);

z(1) = r_1(yA).*(1 - a_mut.* yB./(1 + yB)) .* ( 1 - (par.a_11.*ys+ a_12.*yr)./par.K )*ys - d_1(yA) * ys;
z(2) = par.r_2*(1 - (a_21.*ys + par.a_22.*yr)./par.K).*yr + a_mut.* yB./(1 + yB) .* r_1(yA).*( 1 - (par.a_11.*ys + a_12.*yr)./par.K)*ys - par.d_2 * yr;

z(3) = par.alpha_1.*yA.*ys + par.alpha_2.*yr - par.gamma_P.*yP.*(ys + yr).^par.m./(par.K_P + ys + yr) - par.mu_P.*yP;
z(4) = par.gamma_P.*yP.*(ys + yr).^par.m./(par.K_P + ys + yr) - par.mu_PS.*yPS;

z(5) = par.k_11.*yR.*yD - par.k_12.*yA - par.mu_A.*yA;   % A1
z(6) = par.lambda_R - par.k_11.*yR.*yD + par.k_12.*yA-par.mu_R.*yR;   % R1

z(7) = par.beta_D.*yTS/(par.b_D + yTS) + par.beta_0./(1 + alpha * yB) .* ys - par.k_11.*yR.*yD + par.k_12.*yA - par.mu_D.*yD;   % D1
z(8) = par.lambda_TS - par.beta_D.*yTS/(par.b_D + yTS) - par.mu_TS * yTS;

z(9) = par.lambda_A*u - par.gamma_A.*yB;

end



% The growth rate of sensitive cells
function r_1 = r_1(yA)

global par
r_1 = par.q_1.*yA.^par.n./(par.q_2.^par.n + yA.^par.n) ;

end

% The death rate of sensitive cells
function d_1 = d_1(yA)

global par
d_1 = par.q_3/(par.q_4 + yA);

end

