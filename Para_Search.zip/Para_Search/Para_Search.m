% 
function Para_Search(k0,k1)


for k = k0:k1
    
    a_12 = floor((k-1)/20)+1;
    a_21 = mod((k-1),20)+1;
    findtotalRMSE(a_12, a_21, k);
    
end

end




