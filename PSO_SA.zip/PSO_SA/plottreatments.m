%%
function plottreatments()
clear all;close all;

for patientIndex  = 23

T = dir(strcat('output/',num2str(patientIndex),''));
Tm = length(T)-2;
Tm = 2000;
xlin = 0;
% K0 = 10000;
% P = [u, Y, J] = [u,  ys,yr,yP,  yPS,yA,yR,  yD,yTS, J]

for i = 1:Tm   % 18 21 need   % 17 19 very no 
P((i-1)*100+1:i*100,:) = load(strcat('output/',num2str(patientIndex),'/Treatment-A',num2str(i),'.dat'));
% [u, Y, J] = [u,  ys,yr,yP,  yPS,yA,yR,  yD,yTS, J]
end

A = zeros(Tm,1);
for i = 1:Tm
    A(i,1) = P((i-1)*100+1,1);
end

n = floor(Tm/7);
B = zeros(n,7);
for i = 1:n
    for j = 1:7
        B(i,j) = A(7*(i-1)+j,1);
    end
end
% down data for drawing, in units of 7 days
 % dlmwrite(strcat('Optimal_treatment/Treatment_data/',num2str(patientIndex),'B.dat'),B,' ')

figure(1)

A = suptitle(strcat('Patient P100',num2str(patientIndex))); 
set(gcf,'outerposition',get(0,'screensize'))
set(A,'FontSize',12)
set (gcf,'position', [50,50,1200,600]);

subplot(211)
plot(0.01:0.01:Tm,P(:,5))
xlim([xlin,Tm])
xlabel('Time/days');
ylabel('PSA/nM');
% ylim([0,260])

subplot(212)
yyaxis left
hold on
plot(0.01:0.01:Tm,(P(:,2)),'b')
hold on
xlim([xlin,Tm])
ylim([2000,5000])
xlabel('Time/days');
ylabel('T_1/cells');


yyaxis right
plot(0.01:0.01:Tm,(P(:,3)),'r')
xlim([xlin,Tm])
% ylim([0,5000])
xlabel('Time/days');
ylabel('T_2/cells');

% saveas(gcf,['Optimal_treatment/Treatment_figure/' num2str(patientIndex) '.png'])
end
