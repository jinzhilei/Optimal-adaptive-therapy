function Y = NextDay(Y0,yB,patientIndex)
% ����ǰһ���� Y0,������һ����Y1 
% Y1 = [1~8]
global par md
parameter(patientIndex)
control()
K = par.K;
h = md.h;

Y = zeros(101,8);
Y(1,:) = Y0;

for i = 2:101
k1 = Model(Y(i-1,:), yB(i-1) );
k2 = Model(Y(i-1,:) + (h/2)*k1, yB(i-1) );
k3 = Model(Y(i-1,:) + (h/2)*k2, yB(i-1) );
k4 = Model(Y(i-1,:) + h*k3, yB(i-1) );

Y(i,:) = Y(i-1,:) + (h/6)*(k1 + 2 * k2 + 2 * k3 + k4);

%  Y1 = [ys,yr,yP,  yPS,yA,yR,  yD,yTS,yB]
Y(i,1) = max(Y(i,1) , 0);
Y(i,2) = max(Y(i,2) , 0);

Y(i,1) = min(Y(i,1) , K);
Y(i,2) = min(Y(i,2) , K);

Y(i,3) = max(Y(i,3),0);
Y(i,4) = max(Y(i,4),0);   

Y(i,5) = max(Y(i,5),0);
Y(i,6) = max(Y(i,6),0);
Y(i,7) = max(Y(i,7),0);
Y(i,8) = max(Y(i,8),0);
end
Y = Y(2:101,:);
end