function A = survival()
clear all;close all;
sigma_p = 5;
yRm = 1300;
for patientIndex  = 1:28

T = dir(strcat('output/',num2str(patientIndex)));
Tm = length(T)-3;
% Tm = 3;
% K0 = 10000;
% S = [u, Y, J] = [u,  ys,yr,yP,  yPS,yA,yR,  yD,yTS, J]

control()
global md
h = md.h;
tmax = length(0:h:Tm);
out = zeros(tmax,1);
S = zeros(tmax,10);
P0 = zeros(100,1);
for i = 1:Tm
    
S((i-1)*100+1:i*100,:) = load(strcat('output/',num2str(patientIndex),'/Treatment-A',num2str(i),'.dat'));
Rcell = S((i-1)*100+1:i*100,3);
n = length(Rcell);

for j = 1:1:n
    
P0(j) = 0.01/( 1+exp(-(Rcell(j)-yRm)/sigma_p) );
a=[0 1];
Prob=[P0(j) 1-P0(j)];
out((i-1)*100+j,1) = randsrc(1,1,[a;Prob]);
end
end

A0 = length(find(out(:,1)==0));
out(1:A0,2) = find(out(:,1)==0)/100;
A = out(1:120,2);
% dlmwrite(strcat('output/out',num2str(patientIndex),'.dat'),out,' ')

end

end