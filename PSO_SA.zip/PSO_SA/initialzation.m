%
%
function y0 = initialzation(S0, R0, PSA)
% ys(0)   yr(0)   P(0)   P_S(0)   A(0)   R(0)  D(0)  T_S(0)

y0 = [S0, R0,PSA*10,PSA,94.56,16, 15, 1.7336];
% the initialzation of PSA in tissue is importance.
end