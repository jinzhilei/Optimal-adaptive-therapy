function createtextbox(figure1)
%CREATETEXTBOX(figure1)
%  FIGURE1:  annotation figure

%  �� MATLAB �� 21-Aug-2024 15:33:17 �Զ�����

% ���� textbox
annotation(figure1,'textbox',...
    [0.377388888888889 0.81025641025641 0.0610370370370369 0.0282051282051282],...
    'String',{'R^2 = 0.7445'},...
    'FitBoxToText','off');

