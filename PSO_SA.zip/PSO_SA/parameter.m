%
%

function parameter(patientIndex)

R = xlsread('Optimal_para/para.xlsx');
global par
par.r_2 = R(1,patientIndex);
par.d_2 = R(2,patientIndex);

par.q_1 = R(3,patientIndex);
par.q_2 = R(4,patientIndex);
par.q_3 = R(5,patientIndex);
par.q_4 = R(6,patientIndex);
             
par.gamma_P = R(7,patientIndex); 
par.alpha = R(8,patientIndex);   
par.alpha_1 = R(9,patientIndex);
par.alpha_2 = R(10,patientIndex);  
par.a_mut = R(11,patientIndex);

%% ---------------------------------------
% --------------------
% 
par.K = 1e4;
par.K_P = 1e4;     
par.beta_0 = 3;     

par.a_11 = 1;
par.a_12 = 1; 
par.a_21 = 3; 
par.a_22 = 1;

par.k_11 = 0.28; 
par.k_12 = 0.035; 
par.n = 2;  
par.m = 2;   
par.lambda_A = 1.61;
par.gamma_A = 1.6; 

% -------------------------------
% --
par.mu_A = 24*log(2)/12;   
par.mu_D = 24*log(2)/9;   
par.mu_R = 24*log(2)/6.6;  
par.mu_TS = 24*log(2)/3;   
  
par.mu_P = 24*log(2)/12.3; 
par.mu_PS = 24*log(2)/0.12; 
par.lambda_R = 2.23e3;     
par.lambda_TS = 92.44;   

par.beta_D = 4.569;
par.b_D = 1;        
par.c_p = 0.0023;
par.gamma_0 = 0.0001;

end